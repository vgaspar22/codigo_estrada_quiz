import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

/// Tela exibida após o término do quiz.
/// Mostra a pontuação final do utilizador.
class ResultScreen extends StatelessWidget {
  /// Pontuação total do utilizador, passada pela [QuizScreen].
  final int score;

  /// Construtor da tela de resultado.
  /// Requer a pontuação obtida [score].
  const ResultScreen({super.key, required this.score});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Barra de título
      appBar: AppBar(title: Text('Resultado')),

      // Corpo da tela: exibe a pontuação centralizada
      body: Center(
        child: Text(
          'Pontuação: $score',
          style: TextStyle(fontSize: 30),
        ),
      ),
    );
  }
}
