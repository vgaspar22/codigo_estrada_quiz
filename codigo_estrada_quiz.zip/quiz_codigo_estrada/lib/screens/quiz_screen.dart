import 'package:flutter/material.dart';
import '../models/question.dart';
import '../services/firestore_service.dart';
import '../screens/result_screen.dart';

/// Tela principal do quiz, onde as perguntas são exibidas uma por uma.
/// Ao final, redireciona para a tela de resultados.
class QuizScreen extends StatefulWidget {
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  // Instância do serviço que comunica com o Firestore
  final _firestore = FirestoreService();

  // Lista de perguntas carregadas do Firestore
  List<Question> _questions = [];

  // Índice da pergunta atual
  int _current = 0;

  // Pontuação acumulada
  int _score = 0;

  /// Inicializa o estado e carrega as perguntas ao abrir a tela
  @override
  void initState() {
    super.initState();
    _loadQuestions();
  }

  /// Carrega as perguntas do Firestore e atualiza o estado
  void _loadQuestions() async {
    final data = await _firestore.fetchQuestions();
    setState(() {
      _questions = data;
    });
  }

  /// Trata a resposta selecionada pelo utilizador.
  ///
  /// Se estiver correta, incrementa a pontuação.
  /// Avança para a próxima pergunta ou mostra a tela de resultado.
  void _answer(int index) {
    // Verifica se a resposta está correta
    if (_questions[_current].correctIndex == index) _score++;

    // Se ainda houver mais perguntas, avança
    if (_current + 1 < _questions.length) {
      setState(() => _current++);
    } else {
      // Caso contrário, mostra a tela de resultado
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(score: _score),
        ),
      );
    }
  }

  /// Constrói a interface da tela do quiz
  @override
  Widget build(BuildContext context) {
    // Enquanto as perguntas ainda não foram carregadas, mostra um loader
    if (_questions.isEmpty) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    // Pergunta atual
    final question = _questions[_current];

    return Scaffold(
      appBar: AppBar(title: Text('Pergunta ${_current + 1}')),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Exibe o texto da pergunta
            Text(
              question.text,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 20),

            // Gera os botões de resposta com base nas opções disponíveis
            ...List.generate(question.options.length, (index) {
              return ElevatedButton(
                onPressed: () => _answer(index), // Ao clicar, verifica a resposta
                child: Text(question.options[index]),
              );
            }),
          ],
        ),
      ),
    );
  }
}
