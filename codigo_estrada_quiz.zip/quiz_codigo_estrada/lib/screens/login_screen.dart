import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'home_screen.dart';

/// Tela de login e registo de utilizadores.
/// Permite autenticar com email e senha usando Firebase Authentication.
class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // Controladores para capturar o texto inserido nos campos de email e senha
  final _email = TextEditingController();
  final _password = TextEditingController();

  /// Função para autenticar o utilizador (login) com email e senha.
  ///
  /// Se bem-sucedido, redireciona para [HomeScreen].
  Future<void> login() async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email.text.trim(),      // remove espaços extras
        password: _password.text.trim(),
      );

      // Navega para a tela principal e remove a tela de login da pilha
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => HomeScreen()),
      );
    } catch (e) {
      print(e); // Pode substituir por snackbar ou mensagem na interface
    }
  }

  /// Função para registar um novo utilizador com email e senha.
  ///
  /// Após o registo, redireciona também para [HomeScreen].
  Future<void> register() async {
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _email.text.trim(),
        password: _password.text.trim(),
      );

      // Navega diretamente para a tela principal após registo
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => HomeScreen()),
      );
    } catch (e) {
      print(e); // Idealmente exibir uma mensagem mais amigável ao utilizador
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),

      body: Column(
        children: [
          // Campo de texto para o email
          TextField(
            controller: _email,
            decoration: InputDecoration(labelText: 'Email'),
          ),

          // Campo de texto para a senha (com ocultação do texto)
          TextField(
            controller: _password,
            decoration: InputDecoration(labelText: 'Senha'),
            obscureText: true,
          ),

          // Botão para realizar login
          ElevatedButton(
            onPressed: login,
            child: Text('Login'),
          ),

          // Botão para registar novo utilizador
          ElevatedButton(
            onPressed: register,
            child: Text('Registar'),
          ),
        ],
      ),
    );
  }
}
