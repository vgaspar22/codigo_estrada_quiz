import 'package:flutter/material.dart';

/// Tela inicial do app "Código da Estrada", exibida após o login.
/// Apresenta três ações principais: começar o quiz, ver estatísticas e terminar sessão.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Barra de título da aplicação
      appBar: AppBar(
        title: const Text('Código da Estrada'),
        centerTitle: true, // Centraliza o título na AppBar
      ),

      // Corpo centralizado com espaçamento e botões
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0), // Margem interna de 24 em todos os lados
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Centraliza verticalmente os itens
            children: [
              // Texto de boas-vindas
              const Text(
                'Bem-vindo ao Quiz do Código da Estrada!',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 40), // Espaço vertical

              // Botão para iniciar o quiz (comentado, aguardando implementação da tela)
              ElevatedButton(
                onPressed: () {
                  // TODO: Descomentar quando a tela QuizScreen estiver pronta
                  // Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen()));
                },
                child: const Text('Começar Quiz'),
              ),

              const SizedBox(height: 20), // Espaço entre os botões

              // Botão para visualizar as estatísticas do utilizador
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const EstatisticasScreen()),
                  );
                },
                child: const Text('Ver Estatísticas'),
              ),

              // Botão para terminar sessão (logout do Firebase)
              ElevatedButton(
                onPressed: () async {
                  await FirebaseAuth.instance.signOut(); // Termina a sessão do utilizador
                  Navigator.pop(context); // Volta para a tela anterior (login)
                },
                child: const Text('Terminar Sessão'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
