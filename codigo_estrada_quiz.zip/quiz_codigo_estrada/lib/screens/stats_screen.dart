import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

/// Tela que mostra as estatísticas do utilizador,
/// como total de pontos, número de quizzes feitos e média por quiz.
class EstatisticasScreen extends StatelessWidget {
  const EstatisticasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      // Chamada assíncrona para obter os dados estatísticos
      future: obterEstatisticas(),

      // Constrói a interface com base no estado do Future
      builder: (context, snapshot) {
        // Enquanto os dados ainda estão a carregar
        if (!snapshot.hasData) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()), // Indicador de carregamento
          );
        }

        // Dados retornados com sucesso
        final stats = snapshot.data!;

        return Scaffold(
          appBar: AppBar(title: const Text("Estatísticas")),
          body: Padding(
            padding: const EdgeInsets.all(20.0), // Espaçamento interno da tela
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, // Alinha os textos à esquerda
              children: [
                Text("Total de Pontos: ${stats['pontuacao_total']}"),
                Text("Quizzes feitos: ${stats['quiz_feitos']}"),
                Text("Média por quiz: ${stats['media_por_quiz']}"),
              ],
            ),
          ),
        );
      },
    );
  }
}
