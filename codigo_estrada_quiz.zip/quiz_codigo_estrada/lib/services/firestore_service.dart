import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/question.dart';

/// Serviço responsável pelas operações no Firebase Firestore,
/// como buscar perguntas, salvar resultados e adicionar histórico de pontuações.
class FirestoreService {
  // Instância do Firestore
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// Busca todas as perguntas da coleção 'perguntas' no Firestore.
  ///
  /// Retorna uma lista de objetos [Question]. Se ocorrer erro, retorna uma lista vazia.
  Future<List<Question>> fetchQuestions() async {
    try {
      // Busca todos os documentos da coleção 'perguntas'
      final snapshot = await _db.collection('perguntas').get();

      // Converte os documentos em objetos Question
      return snapshot.docs.map((doc) => Question.fromFirestore(doc.data())).toList();
    } catch (e) {
      // Se ocorrer erro, imprime no console e retorna uma lista vazia
      print('Erro ao buscar perguntas: $e');
      return [];
    }
  }

  /// Salva a pontuação do utilizador em um documento da coleção 'resultados'.
  ///
  /// O documento é identificado pelo [userId]. Registra a [score] e a data atual.
  Future<void> saveResult(String userId, int score) async {
    try {
      await _db.collection('resultados').doc(userId).set({
        'pontuacao': score,
        'data': FieldValue.serverTimestamp(), // data/hora do servidor
      });
    } catch (e) {
      print('Erro ao guardar pontuação: $e');
    }
  }

  /// Adiciona um novo resultado no histórico do utilizador.
  ///
  /// Armazena a [score] e data em uma subcoleção 'historico' dentro do documento do utilizador [userId].
  Future<void> addResultToHistory(String userId, int score) async {
    try {
      await _db
          .collection('utilizadores')
          .doc(userId)
          .collection('historico')
          .add({
        'pontuacao': score,
        'data': FieldValue.serverTimestamp(), // data/hora do servidor
      });
    } catch (e) {
      print('Erro ao guardar histórico: $e');
    }
  }
}
