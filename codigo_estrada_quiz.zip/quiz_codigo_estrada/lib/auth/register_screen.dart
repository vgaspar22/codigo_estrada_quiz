import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/question.dart';

/// Serviço responsável por interações com o Firebase Firestore,
/// como buscar perguntas e armazenar pontuações/resultados dos utilizadores.
class FirestoreService {
  /// Instância do Firestore
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// Busca todas as perguntas da coleção 'perguntas' no Firestore.
  ///
  /// Retorna uma lista de objetos [Question] mapeados a partir dos documentos.
  /// Em caso de erro, imprime no console e retorna uma lista vazia.
  Future<List<Question>> fetchQuestions() async {
    try {
      final snapshot = await _db.collection('perguntas').get();

      // Converte cada documento para um objeto Question
      return snapshot.docs
          .map((doc) => Question.fromFirestore(doc.data()))
          .toList();
    } catch (e) {
      print('Erro ao buscar perguntas: $e');
      return [];
    }
  }

  /// Salva a pontuação final de um utilizador na coleção 'resultados'.
  ///
  /// Sobrescreve (ou cria) o documento com ID igual ao [userId].
  /// Armazena a pontuação ([score]) e a data/hora do servidor.
  Future<void> saveResult(String userId, int score) async {
    try {
      await _db.collection('resultados').doc(userId).set({
        'pontuacao': score,
        'data': FieldValue.serverTimestamp(), // data atual do servidor
      });
    } catch (e) {
      print('Erro ao guardar pontuação: $e');
    }
  }

  /// Adiciona um novo registro de pontuação no histórico do utilizador.
  ///
  /// Armazena a pontuação ([score]) dentro de uma subcoleção 'historico'
  /// no documento do utilizador ([userId]) na coleção 'utilizadores'.
  /// Ideal para manter múltiplos resultados ao longo do tempo.
  Future<void> addResultToHistory(String userId, int score) async {
    try {
      await _db
          .collection('utilizadores')
          .doc(userId)
          .collection('historico')
          .add({
        'pontuacao': score,
        'data': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Erro ao guardar histórico: $e');
    }
  }
}
