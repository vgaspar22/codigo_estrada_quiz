/// Modelo de dados que representa uma pergunta do quiz.
class Question {
  /// Texto da pergunta (ex: "Qual é o limite de velocidade numa zona urbana?")
  final String text;

  /// Lista de opções possíveis de resposta.
  final List<String> options;

  /// Índice da resposta correta dentro da lista [options].
  final int correctIndex;

  /// Construtor da classe [Question].
  Question({
    required this.text,
    required this.options,
    required this.correctIndex,
  });

  /// Construtor de fábrica que cria uma instância de [Question] a partir
  /// de um mapa (como os dados lidos do Firestore).
  factory Question.fromFirestore(Map<String, dynamic> data) {
    return Question(
      text: data['text'],
      options: List<String>.from(data['options']), // Garante que seja lista de Strings
      correctIndex: data['correctIndex'],
    );
  }
}
